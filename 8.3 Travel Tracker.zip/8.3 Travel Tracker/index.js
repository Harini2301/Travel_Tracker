import express from "express";
import bodyParser from "body-parser";
import pg from "pg";
import countryList from "country-list";
const app = express();
const port = 3000;

const db=new pg.Client({
  user:"postgres",
  host:"localhost",
  database:"world",
  password:"harini_kulkarni2512",
  port:5432,
});
db.connect();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

app.get("/",async(req,res)=>{
  const result=await(db.query("SELECT country_code from visited_countries"));
  const countries=[];
  result.rows.forEach((country)=>{
    countries.push(country.country_code);
  });
  console.log(result.rows);
  res.render("index.ejs",{countries:countries,total:countries.length});
  // db.end();
})
app.post("/add", async (req, res) => {
  const input = req.body["country"];
  if (input.length === 2) {
    console.log("country:", input);
    const re = await db.query("INSERT INTO visited_countries(country_code) VALUES($1) RETURNING *", [input]);
    console.log(re);
    const result = await db.query("SELECT country_code FROM visited_countries WHERE country_code = ($1)", [input]);
    console.log("result rows:", result.rows);
    res.redirect("/");
  } else if (input.length > 2) {
    const countryCode = countryList.getCode(input);
    console.log("country:", countryCode);
    if (!countryCode) {
      console.error("Invalid country name:", input);
      return res.status(400).send("Invalid country name");
    }
    const re = await db.query("INSERT INTO visited_countries(country_code) VALUES($1) RETURNING *", [countryCode]);
    console.log(re);
    const result = await db.query("SELECT country_code FROM visited_countries WHERE country_code = ($1)", [countryCode]);
    console.log("result rows:", result.rows);
    res.redirect("/");
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
